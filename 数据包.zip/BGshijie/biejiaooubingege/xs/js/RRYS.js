Object.assign(muban.首图2.二级, {
    tabs: 'div.bottom-line h3',
});
var rule = {
    模板: '首图2',
    title: '人人影视',
    host: 'https://www.rttks.com',
    url: '/rrtop/fyclassfyfilter.html',
    filter_url: '{{fl.area}}{{fl.by}}/page/fypage{{fl.year}}',
    filter: 'H4sIAAAAAAAAA+2Wy27aQBSG38VrJMakuTRv0GeosjBggUnipFzamihSq1wEoQ1t1UBpSC9SCCAlwii9EEfAyzB2eIuOYZg5nq5YdFNmh//vcGbm9/Af9pS4oZmWYSaU9ad7yqZuKetKTMvqT+JKSDG1bZ08e917/KVEng3TyJJn8um5tpXTJ18xiYCPWuODli/7dD9E1WLTPTiiaurZLgeVOmEUvEwBcNIa9esUxPMceIUub6WBVl7zPb67p2AzyYH7+p37qjIDUQAKn0ZOkYK8v8aGj6Yn19K6xs+N6zZ+48x97lHvBp/38WVzXDumLOw3DlMpWDe+qrm9TqCOSkK/su3eDYL9phLzYnBK6gIVVJpVjL+2xQoqMXeqDbd+HaigEqu4tcUeVGIVFRuffMMX34NFTGW7aV+7F42HxnDkfA7uCQJ2N97a2LkKnn8qzSoeSl1xZ1Tiez/7e+9nsIJs0S0NyYsKLsRUtlZj6JVvvGItuBxT2bsbHnr9qlsJvmCusp0Nbkl7XGiLXgQAvKqWrqX5VXWrv8bVH3Nf1QiKPJot5zcMTwRAl0S6BGlEpBFIVZGqkCKRIkDVxwIlAqBrIl2DdFWkq5CuiHQF0mWRLkMqeqVCr1TRKxV6pYpeqdArVfRKhV6polcq9AqJXiHoFRK9QtArJHqFoFdI9ApBr5DoFRHgBY1a4HqefsBOee7ryW71ZJmoFc4apB37bTmOa38ENGlkM/wX2jnEhWNAM7GdtO7vcCM0GXqZpJHK/YOpd94fOU0+3xKxFD9Pr0MyG7AsYNWGn8WMpZOA/fyNLyucJV+k5NiSY0uOLTm25NhapLG1Yya2NRMMLZn8Mvll8svkl8n/fyd/niS/Zcjgl8Evg18Gvwz+hQn+lLGV2zXkf34Z/TL6ZfTL6F+Y6N//A5OZxuqbHwAA',
    searchUrl: '/rrcz**/page/fypage.html',
}